package com.example.myapplication;


public class Datainfopkl {
    private String idinfo,ketinfo,detinfo;
    public Datainfopkl() {

    }

    public String getIdinfo() {
        return idinfo;
    }

    public void setIdinfo(String idinfo) {
        this.idinfo = idinfo;
    }

    public String getKetinfo() {
        return ketinfo;
    }

    public void setKetinfo(String ketinfo) {
        this.ketinfo = ketinfo;
    }

    public String getDetinfo() {
        return detinfo;
    }

    public void setDetinfo(String detinfo) {
        this.detinfo = detinfo;
    }

    public Datainfopkl(String idinfo, String ketinfo, String detinfo){
        this.idinfo=idinfo;
        this.ketinfo=ketinfo;
        this.detinfo=detinfo;

    }





}

