package com.example.myapplication;

public class Datanilai {
    private String idn,nis,nama,indikator1,indikator2,indikator3,indikator4,indikator5,indikator6,indikator7,indikator8,indikator9,indikator10,indikator11,indikator12,indikator13,indikator14,
            indikator1a,indikator2a,indikator3a,indikator4a,indikator5a,indikator6a,indikator7a,indikator8a,indikator9a,indikator10a,indikator11a,indikator12a,indikator13a,indikator14a;
    public Datanilai() {

    }

    public String getIndikator1a() {
        return indikator1a;
    }

    public void setIndikator1a(String indikator1a) {
        this.indikator1a = indikator1a;
    }

    public String getIndikator2a() {
        return indikator2a;
    }

    public void setIndikator2a(String indikator2a) {
        this.indikator2a = indikator2a;
    }

    public String getIndikator3a() {
        return indikator3a;
    }

    public void setIndikator3a(String indikator3a) {
        this.indikator3a = indikator3a;
    }

    public String getIndikator4a() {
        return indikator4a;
    }

    public void setIndikator4a(String indikator4a) {
        this.indikator4a = indikator4a;
    }

    public String getIndikator5a() {
        return indikator5a;
    }

    public void setIndikator5a(String indikator5a) {
        this.indikator5a = indikator5a;
    }

    public String getIndikator6a() {
        return indikator6a;
    }

    public void setIndikator6a(String indikator6a) {
        this.indikator6a = indikator6a;
    }

    public String getIndikator7a() {
        return indikator7a;
    }

    public void setIndikator7a(String indikator7a) {
        this.indikator7a = indikator7a;
    }

    public String getIndikator8a() {
        return indikator8a;
    }

    public void setIndikator8a(String indikator8a) {
        this.indikator8a = indikator8a;
    }

    public String getIndikator9a() {
        return indikator9a;
    }

    public void setIndikator9a(String indikator9a) {
        this.indikator9a = indikator9a;
    }

    public String getIndikator10a() {
        return indikator10a;
    }

    public void setIndikator10a(String indikator10a) {
        this.indikator10a = indikator10a;
    }

    public String getIndikator11a() {
        return indikator11a;
    }

    public void setIndikator11a(String indikator11a) {
        this.indikator11a = indikator11a;
    }

    public String getIndikator12a() {
        return indikator12a;
    }

    public void setIndikator12a(String indikator12a) {
        this.indikator12a = indikator12a;
    }

    public String getIndikator13a() {
        return indikator13a;
    }

    public void setIndikator13a(String indikator13a) {
        this.indikator13a = indikator13a;
    }

    public String getIndikator14a() {
        return indikator14a;
    }

    public void setIndikator14a(String indikator14a) {
        this.indikator14a = indikator14a;
    }

    public String getIdn() {
        return idn;
    }

    public void setIdn(String idn) {
        this.idn = idn;
    }

    public String getNis() {
        return nis;
    }

    public void setNis(String nis) {
        this.nis = nis;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getIndikator1() {
        return indikator1;
    }

    public void setIndikator1(String indikator1) {
        this.indikator1 = indikator1;
    }

    public String getIndikator2() {
        return indikator2;
    }

    public void setIndikator2(String indikator2) {
        this.indikator2 = indikator2;
    }

    public String getIndikator3() {
        return indikator3;
    }

    public void setIndikator3(String indikator3) {
        this.indikator3 = indikator3;
    }

    public String getIndikator4() {
        return indikator4;
    }

    public void setIndikator4(String indikator4) {
        this.indikator4 = indikator4;
    }

    public String getIndikator5() {
        return indikator5;
    }

    public void setIndikator5(String indikator5) {
        this.indikator5 = indikator5;
    }

    public String getIndikator6() {
        return indikator6;
    }

    public void setIndikator6(String indikator6) {
        this.indikator6 = indikator6;
    }

    public String getIndikator7() {
        return indikator7;
    }

    public void setIndikator7(String indikator7) {
        this.indikator7 = indikator7;
    }

    public String getIndikator8() {
        return indikator8;
    }

    public void setIndikator8(String indikator8) {
        this.indikator8 = indikator8;
    }

    public String getIndikator9() {
        return indikator9;
    }

    public void setIndikator9(String indikator9) {
        this.indikator9 = indikator9;
    }

    public String getIndikator10() {
        return indikator10;
    }

    public void setIndikator10(String indikator10) {
        this.indikator10 = indikator10;
    }

    public String getIndikator11() {
        return indikator11;
    }

    public void setIndikator11(String indikator11) {
        this.indikator11 = indikator11;
    }

    public String getIndikator12() {
        return indikator12;
    }

    public void setIndikator12(String indikator12) {
        this.indikator12 = indikator12;
    }

    public String getIndikator13() {
        return indikator13;
    }

    public void setIndikator13(String indikator13) {
        this.indikator13 = indikator13;
    }

    public String getIndikator14() {
        return indikator14;
    }

    public void setIndikator14(String indikator14) {
        this.indikator14 = indikator14;
    }

    public Datanilai(String idn, String nis, String nama, String indikator1, String indikator2, String indikator3, String indikator4, String indikator5, String indikator6, String indikator7, String indikator8, String indikator9, String indikator10, String indikator11, String indikator12, String indikator13, String indikator14
            , String indikator1a, String indikator2a, String indikator3a, String indikator4a, String indikator5a, String indikator6a, String indikator7a, String indikator8a, String indikator9a, String indikator10a, String indikator11a, String indikator12a, String indikator13a, String indikator14a){
        this.idn=idn;
        this.nis=nis;
        this.nama=nama;
        this.indikator1=indikator1;
        this.indikator2=indikator2;
        this.indikator3=indikator3;
        this.indikator4=indikator4;
        this.indikator5=indikator5;
        this.indikator6=indikator6;
        this.indikator7=indikator7;
        this.indikator8=indikator8;
        this.indikator9=indikator9;
        this.indikator10=indikator10;
        this.indikator11=indikator11;
        this.indikator12=indikator12;
        this.indikator13=indikator13;
        this.indikator14=indikator14;
        this.indikator1a=indikator1a;
        this.indikator2a=indikator2a;
        this.indikator3a=indikator3a;
        this.indikator4a=indikator4a;
        this.indikator5a=indikator5a;
        this.indikator6a=indikator6a;
        this.indikator7a=indikator7a;
        this.indikator8a=indikator8a;
        this.indikator9a=indikator9a;
        this.indikator10a=indikator10a;
        this.indikator11a=indikator11a;
        this.indikator12a=indikator12a;
        this.indikator13a=indikator13a;
        this.indikator14a=indikator14a;


    }

}

