package com.example.myapplication;

public class Dataguru {
    private String idg, usernameg, namag, nipg,telpg, keling, keling1, keling2, keling3, keling4, keling5, keling6;
    public Dataguru() {

    }

    public String getKeling5() {
        return keling5;
    }

    public void setKeling5(String keling5) {
        this.keling5 = keling5;
    }

    public String getKeling6() {
        return keling6;
    }

    public void setKeling6(String keling6) {
        this.keling6 = keling6;
    }

    public String getKeling1() {
        return keling1;
    }

    public void setKeling1(String keling1) {
        this.keling1 = keling1;
    }

    public String getKeling2() {
        return keling2;
    }

    public void setKeling2(String keling2) {
        this.keling2 = keling2;
    }

    public String getKeling3() {
        return keling3;
    }

    public void setKeling3(String keling3) {
        this.keling3 = keling3;
    }

    public String getKeling4() {
        return keling4;
    }

    public void setKeling4(String keling4) {
        this.keling4 = keling4;
    }

    public String getUsernameg() {
        return usernameg;
    }

    public void setUsernameg(String usernameg) {
        this.usernameg = usernameg;
    }

    public String getNamag() {
        return namag;
    }

    public void setNamag(String namag) {
        this.namag = namag;
    }

    public String getNipg() {
        return nipg;
    }

    public void setNipg(String nipg) {
        this.nipg = nipg;
    }

    public String getTelpg() {
        return telpg;
    }

    public void setTelpg(String telpg) {
        this.telpg = telpg;
    }

    public String getKeling() {
        return keling;
    }

    public void setKeling(String keling) {
        this.keling = keling;
    }

    public String getIdg() {
        return idg;
    }

    public void setIdg(String idg) {
        this.idg = idg;
    }

    public Dataguru(String idg, String usernameg, String namag, String nipg, String telpg, String keling){
        this.idg=idg;
        this.usernameg=usernameg;
        this.namag=namag;
        this.nipg=nipg;
        this.telpg=telpg;
        this.keling=keling;
    }




}
