package com.example.myapplication;

public class Dataindustri {
    private String idi, namai, bidangi, alamati,telpi, napemi;
    public Dataindustri() {

    }

    public String getIdi() {
        return idi;
    }

    public void setIdi(String idi) {
        this.idi = idi;
    }

    public String getNamai() {
        return namai;
    }

    public void setNamai(String namai) {
        this.namai = namai;
    }

    public String getBidangi() {
        return bidangi;
    }

    public void setBidangi(String bidangi) {
        this.bidangi = bidangi;
    }

    public String getAlamati() {
        return alamati;
    }

    public void setAlamati(String alamati) {
        this.alamati = alamati;
    }

    public String getTelpi() {
        return telpi;
    }

    public void setTelpi(String telpi) {
        this.telpi = telpi;
    }

    public String getNapemi() {
        return napemi;
    }

    public void setNapemi(String napemi) {
        this.napemi = napemi;
    }

    public Dataindustri(String idi, String namai, String bidangi, String alamati, String telpi, String napemi){
        this.idi=idi;
        this.namai=namai;
        this.bidangi=bidangi;
        this.alamati=alamati;
        this.telpi=telpi;
        this.napemi=napemi;
    }




}
